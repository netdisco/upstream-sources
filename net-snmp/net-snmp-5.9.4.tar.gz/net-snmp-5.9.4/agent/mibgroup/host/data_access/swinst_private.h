void netsnmp_swinst_arch_init(void);
void netsnmp_swinst_arch_shutdown(void);
int netsnmp_swinst_arch_load(struct netsnmp_container_s *, u_int);
