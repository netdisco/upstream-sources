/*
 * module to include the modules
 */

config_require(ip-mib/ipAddressTable/ipAddressTable);
