/*
 * module to include the modules
 */

config_require(ip-mib/ipAddressPrefixTable/ipAddressPrefixTable);
